# Plan — hyper_mve fast-sweep + comprehensive test harness, theory check, and push

## Context

The hyper_mve thesis is at the "final-experiments" stage. SDD reviews and Pkg-07 (baselines) + Pkg-08 (eval/ablation) are landed in the working tree but not committed. The just-finished pilot at `D:\RL\hyper_mve\runs\2agent_06c` (6 runs = 2 presets × 3 seeds, ~324K steps each) validates that v4.7 architecture is stable on the duo (N=2) regime. The user wants four sequential tasks: (1) understand the new diff, (2) read the pilot logs against the theoretical claims, (3) write a comprehensive test runner **and** a fast-training launcher that packs 2 processes per GPU on the existing pool `{2,3,4,5,6,7}` to get 12 concurrent training runs, (4) push everything to origin.

All work happens on the user's Linux GPU box; the local Windows checkout is just where the code is authored. Scripts are placed under `hyper_mve/scripts/` per the repo's existing convention.

## Working-tree summary (Task 1 — done in exploration)

Three pkg-08-spec-driven changes are already staged in the working tree:

1. **`use_coord_desc` → `randomize_order` rename** (`configs/train_config.py`, `planning/mve_planner.py`, `scripts/train_main.py`) with a 1-release-minimum compatibility shim: `@property` READ warning, `__init__`-kwarg WRITE warning with the spec-locked "kwarg is deprecated" wording, CLI alias preserved.
2. **Four-mode planner eval dispatch** (`configs/eval_config.py` + `planning/mve_planner.py`): new `eval_planner_mode ∈ {direct_inference, planner_no_crn, planner_no_coord_desc, planner_full}` + per-call `eval_use_crn` / `eval_randomize_order` overrides on `sample_mve_plan`.
3. **`c_hidden` masking refactor** (`envs/resource_commons/env.py` + `observations.py`): masking moved out of `env.reset/step` into `build_joint_observation(env_cfg=…)`.

Plus three untracked subpackages (`hyper_mve/baselines/`, `hyper_mve/eval/`, `hyper_mve/experiments/`), a `baselines_config.py`, and the AUDIT report. `AUDIT_phases0-2_2026-06-22.md` lists 22 findings, all confirmed resolved by the staged diff.

## Theoretical-feasibility verdict (Task 2 — read-only)

The 6 pilot runs all show: belief loss → ~0 by step 1K, total loss plateaus at ~0.8–1.0 by step 50K, planner entropy drops from ~1.0 (uniform) to ~0.5 (decisive), and the planner-vs-prior `gap` swings from negative at step 0 to positive in steady state (e.g. seed0 `duo_base_lora`: `gap=+7.07` at step 0 worsens to `gap=-11.4` at step 1K but trends upward as policy distillation kicks in). This is **consistent with Assertions A (type-gradient separation), B (per-context capacity), and D (planner CRN+CoordDesc working in tandem)**: the planner produces non-uniform output, returns grow monotonically, and the FiLM-LoRA vs base-LoRA preset comparison shows architecture-sensitive divergence (film variant has higher pi loss / higher entropy floor — interpretable as the FiLM hypernet using more of its capacity). Assertion C (tri-context necessity / belief routing) **cannot be confirmed from the pilot** because no `no_belief` ablation cell ran. Statistical power is also limited (3 seeds, no Welch t-test). The fast-300k sweep planned below is what closes both gaps.

Net: theory is feasible; the pilot validates stability + planner viability; the proposed fast sweep (variants {hyper, baseline_input_wide, baseline_input_deep, no_belief, external_mappo, external_qmix, external_ma_muzero_gh} × 2 seeds) directly tests Assertion C, provides the equal-parameter internal baselines for Assertion B, and pulls in the 3 external MARL baselines (MAPPO, QMIX, MA-MuZero-GH) so the thesis methods table can be populated end-to-end.

## Implementation — Task 3 scripts

### Files to create
- **`hyper_mve/scripts/run_full_tests.py`** — tiered pytest orchestrator
- **`hyper_mve/scripts/train_fast_sweep.py`** — 12-way concurrent training launcher

### Files to edit (minimal surgical changes)
- **`hyper_mve/experiments/sweep.py`** — add `MultiSlotGpuSemaphore` class, 3 new kwargs on `run_sweep` (`gpu_ids`, `slots_per_gpu`, `child_env`), pass `extra_env` to `_spawn_row`, and switch the row-drain loop to a `ThreadPoolExecutor` so multiple slots can actually be busy at once.
- **`hyper_mve/experiments/_sweep_worker.py`** — add `_apply_runtime_tuning()` called at the top of `main()` (before any torch model import) that reads env vars `HYPER_MVE_GPU_MEM_FRAC`, `HYPER_MVE_CUDNN_BENCHMARK`, `HYPER_MVE_MATMUL_PRECISION`.

### Run_full_tests.py — design
Tiered pytest orchestrator that spawns each tier as its own `subprocess.run([sys.executable, "-m", "pytest", …])` so a tier crash never aborts the rest and the parent never imports torch.

- **CLI**: `--mode {fast,full,gpu,slow,all}` (default `all` on Linux), `--report-dir runs/test_reports/<utc-stamp>`, per-tier timeout overrides, `--tiers "1,2,3,4"`, `--fail-fast`, `--verbose`, `--pytest-extra`, `--skip-collect-check`.
- **Tiers**:
  - Tier 1 (pure-Python, no torch): `tests/configs/`, `tests/schemas/`, `tests/migration/`, plus 10 specific files under `tests/experiments/` (registry schema, jsonl atomicity, config hash, gpu semaphore, sweep cartesian, use_coord_desc rename, stats, compare, disclosure, ablation CLI), `tests/integration/test_pkg08_drift_detectors.py`, `tests/test_legacy_import_warning.py`. Marker filter `-m "not gpu and not slow"`. Force CPU via `env["CUDA_VISIBLE_DEVICES"] = ""`.
  - Tier 2 (torch CPU): `tests/envs/`, `tests/models/`, `tests/training/`, `tests/planning/`, plus the 4 non-smoke baseline tests under `tests/baselines/external/`. Same marker filter, same CPU forcing.
  - Tier 3 (slow): `tests/baselines/external/test_{mappo,qmix,ma_muzero_gh}_smoke.py` with `-m slow`. Default timeout 3600 s.
  - Tier 4 (GPU): `tests/planning/test_mve_planner.py`, `tests/models/test_forward_performance.py`, `tests/training/test_worker.py`, `tests/training/test_trainer_loop.py` with `-m gpu`. Inherit parent CUDA env (no clearing).
- **Pre-flight**: `pytest tests/ --collect-only -q -W ignore::pytest.PytestUnknownMarkWarning` with its own timeout; abort all tiers on non-zero. Skip via `--skip-collect-check`.
- **Output**: `summary.json` (rollup + per-tier counts + commands + duration), `summary.md` (markdown table for thesis appendix), `<tier>.txt` / `<tier>.stderr.txt` / `<tier>.cmd.txt` per tier, `env.json` (python/platform/torch/CUDA detection), `collect_only.txt`, optional `notes.txt` for "pytest-timeout missing" warnings.
- **Parsing**: capture stdout and apply summary regexes `(\d+) passed|failed|error|skipped|xfailed|warning` against the last `=== … ===` line. Returncode 5 → `status="empty"` (soft-pass). Returncode timeout → `status="timeout"`. Truncate captured stdout at 10 MB.
- **Edge cases**: `pytest-timeout` probed via `importlib.util.find_spec`; KeyboardInterrupt writes partial summary + exits 130; report-dir collision creates `_001`, `_002` siblings; `PYTHONIOENCODING=utf-8` + `PYTHONUTF8=1` injected per subprocess.
- **Exit codes**: 0 = all passed, 1 = any tier failed/errored/timed-out, 2 = collect-only failed, 130 = interrupted.

### Train_fast_sweep.py — design

User-confirmed sweep surface: **`preset=duo_base_lora × variants=[hyper, baseline_input_wide, baseline_input_deep, no_belief, external_mappo, external_qmix, external_ma_muzero_gh] × seeds=[0,1] = 14 rows`**. 12 concurrent slots → 12 rows run at once, 2 queue and start the moment a slot frees. Internal variants train via the hyper_mve trainer; the 3 external variants run their own algorithm loops (MAPPO, QMIX, MA-MuZero-GH) inside `_sweep_worker.py`.

- **CLI defaults match the user's constraints exactly**:
  - `--preset duo_base_lora` (mirrors the 2agent_06c "basegen" cell)
  - `--variants hyper baseline_input_wide baseline_input_deep no_belief external_mappo external_qmix external_ma_muzero_gh`
  - `--seeds 0 1`
  - `--max-steps 300000`
  - `--gpus 2 3 4 5 6 7`
  - `--slots-per-gpu 2`
  - `--runs-root runs/fast_300k`
  - `--mem-frac 0.45` (per-process VRAM cap)
  - `--max-parallel 12`
  - `--cudnn-benchmark` ON, `--matmul-precision high`
  - `--eval-planner-mode planner_full`, `--ablation-cell-id fast_300k`
  - `--extra-override "section.field=value"` (repeatable) for ad-hoc overrides
  - `--retry-failed`, `--dry-run`
- **Pre-flight validation**:
  - Every variant must be in `hyper_mve.baselines.CLI_CHOICES` (raise early with the full valid set in the error).
  - When `torch` imports cleanly, every GPU id must be < `torch.cuda.device_count()`; otherwise skip the check (allows dry-runs on Windows).
- **Resume policy** (user-confirmed): use the existing `run_sweep` resume semantics — rows matching `(variant, seed, config_hash)` and already `completed` are skipped; `failed` rows require `--retry-failed`. Do NOT auto-delete or auto-suffix.
- **Manifest**: write `runs/fast_300k/sweep_manifest.json` listing every row's `run_id`, `run_tag`, variant, seed, assigned `gpu_id`, TB dir, checkpoint path, eval report path, status, walltime, and the final `return_mean`. Re-emit on every invocation (idempotent w.r.t. registry).

### Sweep.py edits — design

1. **`MultiSlotGpuSemaphore`** class added next to `GpuSemaphore`:
   - Constructor: `(gpu_ids: Sequence[int], slots_per_gpu: int = 1)`. Queue holds `len(gpu_ids) * slots_per_gpu` tokens — each gpu_id repeated `slots_per_gpu` times.
   - `acquire() -> int` returns a physical gpu_id; `release(gpu_id)` validates membership and pushes back.
   - Same public surface as `GpuSemaphore` (`n_gpus`, `acquire`, `release`) so callers swap transparently.
2. **`run_sweep` signature extension** (3 new optional kwargs, all defaulted, no caller breakage):
   - `gpu_ids: Sequence[int] | None = None` — when set, use explicit physical ids (so {2..7} not {0..5}).
   - `slots_per_gpu: int = 1` — drives the MultiSlot path; default preserves legacy GpuSemaphore.
   - `child_env: Mapping[str, str] | None = None` — env injected into every spawned worker.
3. **Parallel drain (critical)**: the existing serial loop `for row in rows: gpu_id=sem.acquire(); _spawn_row(...); sem.release(gpu_id)` makes `slots_per_gpu=2` a no-op (only one row ever in flight). Factor the loop body into `_process_one_row(row)` and dispatch via `concurrent.futures.ThreadPoolExecutor(max_workers=max_parallel)`. The registry append is already file-lock-safe (`tests/experiments/test_run_registry_jsonl_append_atomic.py` covers it), so this is safe.
4. **`_spawn_row` extension**: new kwarg `extra_env: Mapping[str, str] | None`; merge into `env` after `CUDA_VISIBLE_DEVICES` is set, before `Popen`.
5. **Dry-run**: include `slots_per_gpu`, `gpu_ids`, and `effective_concurrent = len(gpu_ids)*slots_per_gpu` in the emitted summary.

### _sweep_worker.py edits — design

Add `_apply_runtime_tuning()` called at the very top of `main()`, **before** `json.loads`:
- `HYPER_MVE_GPU_MEM_FRAC=0.45` → `torch.cuda.set_per_process_memory_fraction(0.45, 0)`. Device index `0` is correct because `CUDA_VISIBLE_DEVICES=<phys_id>` makes the physical GPU appear as logical device 0 inside the child.
- `HYPER_MVE_CUDNN_BENCHMARK=1` → `torch.backends.cudnn.benchmark = True`.
- `HYPER_MVE_MATMUL_PRECISION=high` → `torch.set_float32_matmul_precision("high")`.
- Linux only: `torch.multiprocessing.set_sharing_strategy("file_system")`. Guard with `if sys.platform != "win32"`.
- Wrap each call in `try/except` and print a one-line warning to stderr on failure; do NOT crash the worker.

### Risks called out for the implementer

- **`baseline_*`/`no_belief`/`external_*` variants are listed as "runner-owned" in `train_main.py` and exit gracefully when invoked directly** — they expect the pkg-08 sweep harness to drive them through `_sweep_worker.py`. The implementer must verify with two 100-step smokes — one internal (`--max-steps 100 --variants baseline_input_wide --seeds 0`) and one external (`--max-steps 100 --variants external_mappo --seeds 0`) — that `_sweep_worker.py` actually trains these variants end-to-end. If a class of variants short-circuits (worker also skips them), the immediate fallback is to drop that class from `--variants`; fixing `_sweep_worker.py` for that class is out of scope for this PR but should be flagged as a follow-up task. The external trio (mappo/qmix/ma_muzero_gh) is the most fragile here — they wrap PettingZoo-adapted training loops with their own hyper-param schedules and may need `--max-steps` re-interpreted (env steps vs grad steps) — verify with the smoke before the real launch.
- **cuBLAS handle init contention** with `slots_per_gpu=2`: first kernel launch in each child may stall a few seconds. Acceptable; if it surfaces as a real failure (OOM or hang > 60 s), drop to `--slots-per-gpu 1`. Launcher prints a one-line warning to stderr on every `slots_per_gpu > 1` invocation.
- **`set_per_process_memory_fraction` must run BEFORE the first CUDA allocation in the child**. Putting it at the top of `_sweep_worker.py::main()` (before any `import torch` of project modules) is correct because the worker entry imports torch lazily; do not move it.
- **AMP / autocast intentionally not enabled** — would change the loss surface and the trainer has no flag for it. Out of scope.
- **`TrainConfig` has no `cudnn_benchmark` / `matmul_precision` fields**, so `--override "train.cudnn_benchmark=true"` would `TypeError`. The env-var path through `_sweep_worker.py` is the only safe way.

## Push to origin — Task 4

Sequence:
1. Show `git status` + `git diff --stat HEAD` to the user; confirm what gets staged.
2. Split the commits cleanly along feature lines so the history stays readable:
   - **Commit 1**: working-tree mods (pkg-08 spec compliance) — train_config / mve_planner / train_main / eval_config / hyper_muzero_model / env+observations / SDD docs / planner test rename.
   - **Commit 2**: new pkg-07/08 subpackages — `hyper_mve/baselines/`, `hyper_mve/eval/`, `hyper_mve/experiments/`, `hyper_mve/configs/baselines_config.py`, new test dirs (`tests/baselines/`, `tests/experiments/`, `tests/integration/`), `requirements.txt`, `sdd/pkg-08-eval-and-ablation/PHASE6_RUNTIME_CHECKLIST.md`, `AUDIT_phases0-2_2026-06-22.md`, `.audit_reverify_workflow.js`.
   - **Commit 3**: sweep.py + _sweep_worker.py extensions (multi-slot semaphore, threadpool drain, runtime tuning).
   - **Commit 4**: new launcher scripts (`run_full_tests.py`, `train_fast_sweep.py`).
3. Push `main` to `origin/main`. Plain push, no force; no rebase (the repo has no local rebase activity on `main`).
4. **Excluded from commit by default**: `runs/` (gitignored — pilot data and test reports stay local), `__pycache__/`, `.claude/settings.local.json` (local tool state). Ask the user before staging any of these.
5. Confirm with the user before pushing — destructive ops require explicit greenlight.

## Verification (end-to-end, all four tasks)

1. `python hyper_mve/scripts/run_full_tests.py --help` — renders.
2. `python hyper_mve/scripts/run_full_tests.py --mode fast` on the Linux box — should fully pass (Tier 1 + 2). Inspect `runs/test_reports/<utc>/summary.md`.
3. `python hyper_mve/scripts/run_full_tests.py --mode all` on the Linux box — should pass all 4 tiers. Tier 3 will take ~30–60 min (slow baselines smokes).
4. `python -m pytest tests/experiments/test_gpu_semaphore.py -v` — back-compat check for the existing `GpuSemaphore`.
5. `python hyper_mve/scripts/train_fast_sweep.py --dry-run` — prints 14 rows × 12 slots (2 queue).
6. Internal smoke: `python hyper_mve/scripts/train_fast_sweep.py --variants hyper baseline_input_wide --seeds 0 --max-steps 100 --gpus 2 --slots-per-gpu 1 --runs-root runs/_fast_smoke_int` — both rows complete in <5 min.
7. External smoke: `python hyper_mve/scripts/train_fast_sweep.py --variants external_mappo external_qmix external_ma_muzero_gh --seeds 0 --max-steps 100 --gpus 2 --slots-per-gpu 1 --runs-root runs/_fast_smoke_ext` — verify the 3 external runners actually train (not short-circuit).
8. Real run: `python hyper_mve/scripts/train_fast_sweep.py` — 14 rows, 12 slots busy initially + 2 queued, `nvidia-smi` shows 2 processes per used GPU. TB scalars written under `runs/fast_300k/<run_tag>/tb/`. `runs/fast_300k/sweep_manifest.json` produced.
9. After all runs complete: `python -c "import json; [json.loads(l) for l in open('runs/fast_300k/registry.jsonl')]; print('OK')"` — registry valid.
10. Push: `git status`, `git log --oneline -5`, `git push origin main`.
