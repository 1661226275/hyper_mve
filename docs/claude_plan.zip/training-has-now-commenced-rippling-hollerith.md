# Modular Thesis Experiment Suite + Analysis Layer + scripts/ Cleanup

## Context
Training started, but the two live launchers (`train_fast_sweep.py`, `run_lora_experiments.py`) only
cover **Decision-Gate-0** (gen-scope on `duo`, 2 seeds / 300K). The thesis
(`docs/Hyper_MuZero_v4_Roadmap.md` + `docs/Chapter6_Experiments_v4.md`) requires a **main comparison +
5 ablations + zero-shot + belief/curriculum + ∂R/∂u viz**, each with an **Easy (N=2) decision-gate
tier before the Medium headline run**. Several required experiments aren't defined as runnable cells,
and Table 6.1 needs 5 welfare metrics of which only 1 exists. **Assessment: current data cannot support
the thesis** (coverage table below).

**Goal:** a *modular* suite (declarative cells + one runner with selective re-run down to a single run)
+ a *complete* analysis layer (generic tool + thesis table/figure renderers) + the eval-metric
extension Table 6.1 needs, then an aggressive `scripts/` cleanup, committed to `main`.

**Locked scope (confirmed, with this revision):**
- ① **Scaffold all, flag blocked** — orchestration + analysis; the **only** code change beyond
  orchestration is the **4-metric eval extension** (§F, now in scope). No model/env-dynamics changes.
- ② **Explicit targeting** for re-run (`--only/--variants/--seeds/--force`).
- ③ **Commit to `main`**.  ④ **Aggressive** cleanup.
- **Easy (N=2) tier added** to every headline experiment (decision-gate before Medium).
- **Deferred (stay BLOCKED):** Abl2 masking variants (no_type/no_cap/only_c), external stubs
  MAMBA/MARIE/GA, and the ∂R/∂u probe (Fig 6.7).

### Coverage assessment (answer to "can current data support the thesis?")
| Thesis experiment | Required | Today |
|---|---|---|
| 主对比 (Table 6.1, Fig 6.1–3) | Medium, 5 seeds, 1M, 7 methods, 5 metrics | ❌ not run; 3/6 baselines stubs; **4/5 metrics absent → fixed in §F** |
| 消融1 B′ (Table 6.2) | Medium, 3 seeds | ⚠️ `abl1_gen_scope.yaml` exists, not run |
| 消融2 C (Table 6.3) | 5 variants | ❌ no cell; no_type/no_cap/only_c variants don't exist → **deferred** |
| **消融3 A — 生死判官 (Table 6.4, Fig 6.4)** | ρ_β bell curve, 5 seeds | ❌ **completely absent (highest priority)** |
| 消融4 D (Table 6.5) | 2×2 CRN×CoordDesc | ⚠️ `abl4_*.yaml` exist, not run |
| 消融5 (Table 6.6) | 3×3 Fehr-Schmidt | ⚠️ `abl6.yaml` exists, not run |
| 零样本 (Table 6.7, Fig 6.5) | Medium, 5 seeds | ⚠️ partial (abl1 zs cells) |
| Belief/curriculum, ∂R/∂u (Fig 6.6/6.7) | — | ❌ no launcher; ∂R/∂u **deferred** |

---

## Design

### A. Cell format + loader
Each experiment = one declarative YAML reusing `SweepConfig`. Because `SweepConfig.from_yaml` is
**strict** (unknown key → ValueError), add a `meta:` block popped before the strict parse.
- **Refactor** `experiments/sweep.py`: extract `_from_mapping(dict) -> SweepConfig` (current
  `load_yaml` body minus the read); `load_yaml` + new loader both call it.
- **New** `experiments/suite/cell.py`: `SuiteCell` + `load_cell(path)` → pops `meta` (id, title,
  tier∈{must_have,degradable,cuttable}, deliverables, assertion, size∈{easy,medium}, runs_subdir,
  blocked_on, code_deps), passes rest to `sweep._from_mapping`.
- **New** `experiments/suite/manifest.yaml`: ordered list of ALL cells with tier + size + path, in
  decision-gate order (Easy gates before Medium headlines): abl3_easy → abl3 → abl1_easy → abl1 →
  zero_shot_easy → zero_shot → main_comparison_easy → main_comparison → abl4/abl6/abl7 →
  abl2(blocked) → lr_sweep → lora_*.

### B. Cells to author (`experiments/suite/cells/`) — Easy gate + Medium headline per experiment
- `main_comparison.yaml` (Medium, 1M, 5 seeds, 7 methods) **+** `main_comparison_easy.yaml`
  (Easy N=2 1α+1β, 200K, 3 seeds). Both `must_have`, `blocked_on: [external_mamba,…ga]` (stubs auto-skip).
- `abl3_type_heterogeneity.yaml` — **bell curve**: Medium, 5 seeds, one run **per ρ_β ratio** via
  `env.type_assignment` overrides (`[1,1,1,1]`…`[0,0,0,0]`; ALPHA=0/BETA=1). **+** existing-style
  `abl3_easy_n2.yaml` (Easy N=2: 1α1β/2α0β/0α2β, 3 seeds). Both `must_have`.
- `zero_shot_generalization.yaml` (Medium, 5 seeds, rides `cfg.eval.zero_shot_*`) **+**
  `zero_shot_easy.yaml` (Easy, 3 seeds). `must_have`.
- `abl1_easy.yaml` — Easy N=2, 4 variants {Shared/Input-Wide/Input-Deep/Hyper}, 3 seeds (决策点 2).
  Medium Abl1 stays the existing `abl1_gen_scope.yaml`. `degradable`/`must_have`.
- `lr_sweep.yaml` — Easy, 7 methods × 5 LRs × 3 seeds. `cuttable`.
- `abl2_context_paths.yaml` — **BLOCKED/deferred**: `variants: [hyper, no_belief]` only; comment-lists
  missing variants. *Do NOT list nonexistent variants — the worker exits 1 (fail), not 2 (skip).*
- `lora_gen_scope_duo.yaml` + `lora_gen_scope_medium.yaml` — replace `run_lora_experiments.py`,
  registry-backed (split per preset). `degradable`.
- **Existing** `experiments/ablations/{abl1_gen_scope,abl4_crn_joint,abl4_joint_easy_n2,abl6_fehr_schmidt,abl7_curriculum}.yaml`
  gain a `meta:` header; stay in place (keeps `ablate.py` working); referenced by manifest.

### C. Suite runner — `scripts/run_suite.py`
```
run_suite [--list] [--only ID[,ID]] [--variants V[,V]] [--seeds N[,N]] [--size easy|medium]
          [--force] [--dry-run] [--runs-root runs/suite] [--max-steps N]
          [--gpus 2,3,4] [--slots-per-gpu S] [--max-parallel M] [--retry-failed] [--mem-frac F]
```
- `--list`: print each cell `id | tier | size | deliverables | blocked_on | #rows(after narrowing)`.
- Per selected cell: `cfg = load_cell(path).sweep_config`; narrow via `dataclasses.replace`
  (`--variants` intersect, `--seeds` set, `--size` filter); **per-cell isolation**
  `runs_root/<runs_subdir>/` with its own `registry.jsonl`; call `run_sweep(...)`. Existing
  skip-on-`(variant,seed,config_hash)` means completed rows aren't retrained — the selective-rerun base.
- **`--force`** (append-only-safe): recompute target `(variant,seed,config_hash)` triples (reuse
  `enumerate_cartesian` + run_sweep's hash), **append** a new registry row per target with
  `status="failed"`, `failure_reason="forced re-run (--force)"`, strictly-later `started_at_iso8601`;
  run that cell with `retry_failed=True`. `_resume_skip` picks the latest row (ties → last-appended via
  `>=`), sees `failed`, re-enqueues only those. No line rewritten.

### D. Analysis layer (build `analyze_results.py` FIRST)
- `scripts/analyze_results.py` — generic CLI: `--compare` (registry→per-variant CSV→`compare_methods`→
  `render_plot`+markdown), `--tb` (scrape TB event files for LoRA/TB-only runs), `--disclose`
  (→`stats.render_disclosure_table`). Validate on existing `runs/fast_300k` & `runs/lora_sweep` first.
- `experiments/analysis/`: `registry_io.py` (load + `to_compare_csv` emitting the `variant`+metric CSV
  `compare._load_csv_returns` expects), `tb_scraper.py` (`EventAccumulator`, tbparse fallback),
  `tables.py` (Table 6.1–6.7), `figures.py` (Fig 6.1–6.7), `__init__.py` (deliverable→renderer map).
- `scripts/make_thesis_artifacts.py` — iterate manifest → `results/tables/*.md`, `results/figures/*.png`,
  `results/results_index.md` (status: rendered / partial / BLOCKED+unblock-condition).

| Deliverable | Renderer | Reuses | Status (after §F) |
|---|---|---|---|
| Table 6.1 + Fig 6.1–3 主对比 | `table_6_1`,`fig_6_1..3` | `compare_methods(ref=hyper)`, `render_plot` | **5 metrics OK** (3 stubs absent → marked) |
| Table 6.2 Abl1 | `table_6_2` | `compare_methods` | OK |
| Table 6.3 Abl2 | `table_6_3` | `compare_methods` | **BLOCKED** (2 variants only) |
| Table 6.4 + Fig 6.4 bell | `table_6_4`,`fig_6_4_bellcurve` | per-cell `return_mean` across ratio runs | OK |
| Table 6.5 Abl4 | `table_6_5` | `compute_cross_mode_deltas` | OK |
| Table 6.6 robustness | `fig_6_6_heatmap` | per-cell αβ-grid metrics | **OK** (welfare metrics from §F) |
| Table 6.7 + Fig 6.5 | `table_6_7`,`fig_6_5_retention` | `return_zero_shot_*` | OK |
| Fig 6.6 belief/curriculum | `fig_6_6_belief` | `compute_c_hidden_gap`, `belief_c_mae` | OK |
| Fig 6.7 ∂R/∂u | `fig_6_7_grad` | — | **BLOCKED/deferred** (placeholder) |

### E. Aggressive cleanup (grep-gate each delete: repo-wide search for the module stem; delete only when sole hits are the file + its own docstring)
| File | Action |
|---|---|
| `hyper_mve/scripts/test_eval_runner.py`, `test_vectorized_worker.py` | DELETE (true orphans) |
| `hyper_mve/scripts/test_resource_commons.py`, `test_belief_net_synth.py`, `test_hyper_model_forward.py` | MIGRATE→`tests/smoke/` then DELETE (repoint checklist callers) |
| `hyper_mve/scripts/train_fast_sweep.py` | DELETE → matrix becomes `main_comparison.yaml` |
| `hyper_mve/scripts/run_lora_experiments.py` | DELETE → matrix becomes `lora_gen_scope_*.yaml` (+ TB scraper) |
| `scripts/run_test_checklist*.py`, `scripts/audit_legacy.py`, `scripts/perform_archive.ps1` | REVIEW→DELETE (superseded by pytest tree / one-shot) |
| **KEEP** | `train_main.py` (imported by `_sweep_worker`), `run_full_tests.py`, `diagnose_mve.py`, `proposition_3_1_validation.py`, all `tests/` |

### F. Eval metric extension — 4 welfare metrics (the one code change beyond orchestration)
**Definitions (Ch3.8.3):** physical welfare $\Sigma u$ (cross-type comparable), total welfare $\Sigma R$
(incl. Fehr-Schmidt), sustainability $S=\Sigma_k q_{k,T_{\max}}/(K\,Q_{\max})$, fairness
$F=1-N\sigma(W_i^{phys})/\Sigma_i W_i^{phys}$, tragedy $T=\mathbb 1[S<0.2]$. `return_mean` already equals
one of {physical, total} — **resolve which during impl** (env reward is subjective $R$, so `return_mean`
likely = total; physical $\Sigma u$ comes from `info['harvests']`). Add the missing welfare + S + F + T.
- `eval/eval_report.py`: **+4 frozen float fields** (`welfare_physical_mean` or `welfare_total_mean`,
  `sustainability_mean`, `fairness_mean`, `tragedy_index_mean`); 32→36 payload. **Bump `schema_version`
  and update ALL EvalReport lock tests in lockstep** — grep the field-count lock,
  `test_eval_report_schema_lock_matches_spec_08`, and `tests/integration/test_pkg08_drift_detectors.py`
  (`len==33`→`37`).
- `training/evaluation.py` `run_eval`: in the per-c episode loop accumulate per-episode → per-agent
  physical harvest (`info['harvests']`) for physical-welfare + fairness/gini; per-agent reward for total
  welfare; **final-step `info['resource_state']`** for sustainability + tragedy. Return per-c keys.
- `eval/unified_evaluator.py`: aggregate per-c → mean → EvalReport kwargs; assert the eval env is built
  with `eval_info_mode=True` (so `resource_state` is present) in `_verify_env_fn_flags`.
- Collection hook: capture each eval episode's **final info** (resource_state) — thread the last info
  through `run_eval`/`worker.collect_episodes` eval path or snapshot env post-episode (pick the
  least-invasive route during impl).
- Reuse `proposition_3_1_validation._social_welfare` for reward-summing; no existing gini/sustainability.
- Tests: `tests/eval/test_welfare_metrics.py` (4 fields finite; F∈[0,1]; T∈{0,1} on a smoke episode) +
  the schema-lock updates above.

---

## Files: create / modify / delete
**Create:** `experiments/suite/{__init__,cell}.py`, `experiments/suite/manifest.yaml`,
`experiments/suite/cells/*.yaml` (incl. Easy gates: main_comparison(+_easy), abl3(+_easy_n2),
zero_shot(+_easy), abl1_easy, lr_sweep, abl2(blocked), lora_gen_scope_{duo,medium}),
`experiments/analysis/{__init__,registry_io,tb_scraper,tables,figures}.py`,
`scripts/{run_suite,analyze_results,make_thesis_artifacts}.py`,
`tests/experiments/{test_suite_cell_loader,test_run_suite_targeting,test_analyze_results_csv}.py`,
`tests/eval/test_welfare_metrics.py`,
`tests/smoke/{test_resource_commons_smoke,test_belief_net_synth_smoke,test_hyper_model_forward_smoke}.py`.
**Modify:** `experiments/sweep.py` (`_from_mapping`), `experiments/ablate.py` (route through `load_cell`),
`experiments/ablations/*.yaml` (add `meta:`), `eval/eval_report.py` (+4 fields, bump sentinel),
`training/evaluation.py` + `eval/unified_evaluator.py` (compute/aggregate metrics),
EvalReport lock tests, `scripts/run_full_tests.py` (add `tests/smoke/` tier), `hyper_mve/OVERVIEW.md`.
**Delete/merge:** per §E.

## Build sequence
1. `analysis/registry_io.py` + `tb_scraper.py` → `analyze_results.py`; validate on existing `runs/`.
2. **§F eval metrics**: `eval_report.py` +4 fields + sentinel bump + lock-test updates →
   `evaluation.py`/`unified_evaluator.py` compute + collection hook → `test_welfare_metrics.py`.
3. `sweep._from_mapping` refactor + `suite/cell.py` + loader test.
4. `meta:` on existing ablation YAMLs; route `ablate.py`→`load_cell`; `test_ablation_cli_dispatch` green.
5. New cell YAMLs (incl. Easy gates) + `manifest.yaml`.
6. `run_suite.py` + `--force` + targeting test.
7. `analysis/tables.py`+`figures.py`+`__init__.py`; `make_thesis_artifacts.py`.
8. Cleanup: migrate 3 smokes → `tests/smoke/`, wire into `run_full_tests.py`, grep-gate then delete.
9. Commit to `main`.

## Verification
- `run_suite --list` → all cells load; tier/size/deliverables/blocked_on/row-counts correct.
- `run_suite --only abl3_type_heterogeneity --dry-run` → 2×5×5 = 50 rows; `--variants hyper --seeds 0`
  → single run; `--size easy` → only Easy cells.
- **100-step smoke:** `run_suite --only main_comparison_easy --variants hyper --seeds 0 --max-steps 100
  --runs-root runs/_suite_smoke` → trains+evals+writes registry+EvalReport (with the 4 new metrics
  finite); then `analyze_results --compare --registry runs/_suite_smoke/main_comparison_easy/registry.jsonl`.
- **`--force`:** re-run that smoke `--force` → a `failed`/"forced re-run" tombstone appended AND the row re-executes.
- `pytest tests/experiments/test_suite_*.py tests/experiments/test_ablation_cli_dispatch.py
  tests/eval/test_welfare_metrics.py tests/smoke -q`; full schema-lock tests green after the bump.
- `python hyper_mve/scripts/run_full_tests.py --mode fast` → Tier 1+2 green.
- **Verify-during-impl:** (a) confirm the sweep override path converts `env.type_assignment` JSON-lists
  to `AgentType` (as `train_main.apply_overrides` does) before relying on Abl3 cells; (b) resolve
  whether `return_mean` = physical or total welfare; (c) confirm `eval_info_mode` gating exposes
  `resource_state` to the evaluator.

## Git (to `main`)
Commits, each ending with the `Co-Authored-By: Claude …` trailer: 1. eval 4-metric extension + lock-test
updates; 2. suite + analysis + tests; 3. wire `run_suite`/meta-loader/ablate routing; 4. `git rm`
subsumed launchers/orphans/checklists (after grep-gate). Then `git push origin main`.

## BLOCKED / deferred items + unblock conditions
- **Abl2 variants** (Table 6.3) → add masking flags + no_type/no_cap/only_c to `CLI_CHOICES`/`_build_runner`. *(deferred)*
- **MAMBA/MARIE/GA** (Table 6.1, lr_sweep) → source/implement the 3 external stubs (auto-skip until then). *(deferred)*
- **Fig 6.7 ∂R/∂u** → implement offline autograd probe (`eval/grad_probe.py`); placeholder for now. *(deferred)*
- **`regret_per_c`/`return_per_type_ratio` evaluator zeros** → Abl3 bell curve works around via
  one-run-per-ratio; regret column stays blocked until the oracle-ceiling cache lands.
