# Plan: Implement pkg-07 (Baselines) + pkg-08 (Eval & Ablation)

## Context

The hyper_mve SDD process has closed its first loop: pkg-01..pkg-05 are implemented and training/testing has started; pkg-06-baselines is **superseded** (marker at the top of `sdd/pkg-06-baselines/README.md`, 2026-06-19); pkg-07-baselines and pkg-08-eval-and-ablation have spec + design + 8 specs each written and reviewed, with intra-package `check_ref_matrix.ps1` passing. **No implementation code exists yet for pkg-07 or pkg-08.** This plan covers the implementation phase: a Phase 0 verification step (with one correction to the user's stated assumption), then 6 implementation phases in strict dependency order, ending with an end-to-end 11-variant smoke. The intended outcome is the full executable closed loop: 5 internal + 3 Tier-1 external baselines (+ 3 stubs) + unified evaluator + sweep / ablation / stats / compare, all returning the canonical 32-field `EvalReport`.

### Correction to the original assumption

The user said running both `check_ref_matrix.ps1` scripts will confirm the 4 invariants (EvalReport 32-field schema, `.evaluate()` signature, 11 REGISTRY keys, 4 planner-mode literals) are byte-identical between pkg-07 and pkg-08. **This is incorrect.** Both scripts only verify the **intra-package** 8-spec citation graph (e.g. "pkg-07 spec 04 cites specs 05, 06, 08") and emit `ref_matrix.csv` with a delta column. Neither extracts the 4 anchor definitions and diffs them cross-package. The two anchors *are* in fact already byte-identical by design (verified during exploration; pkg-08 spec 01 §3.1 is the mother-doc for the dataclass, pkg-08 spec 08 §3.2 mirrors it; pkg-07 spec 08 §4.1 owns the `.evaluate()` signature, pkg-08 spec 01 §2.1 consumes it; etc.) — but Phase 0 must verify this **separately**, not via the ref-matrix scripts.

### Decisions locked with the user (this session)

1. **`external_ma_muzero_gh`** → real port now from `werner-duvaud/muzero-general` + hand-written MA wrapper. Methods table ships at 10 columns.
2. **MAMBA** → stub from day 1 (raises `NotImplementedError` on instantiation). Design D8 fallback path; sourcing window not opened.
3. **`_DEFERRED_VARIANTS`** in `train_main.py:45-52` → shrink to the 3 stub-CLIs (`external_mamba` / `external_marie` / `external_ga`) so attempting a stub still prints the structured "design D9, see <spec URL>" failure. The 8 newly-real CLIs are removed from the constant.
4. **PettingZoo** → hard-add `pettingzoo` + `gymnasium` to `hyper_mve/requirements.txt`. Module-top imports allowed.
5. (Plan-side default, not asked) Phase 0 byte-identity check is a **one-shot interactive verification**, not a CI-hardened script. The runtime drift detectors (`test_eval_report_32_field_dataclass_lock`, `test_registry_keys_equal_cli_choices_and_factory_args`) authored during implementation are the durable safety net.

---

## Phase 0 — Pre-code verification (one half-day)

### 0.1 Run both ref-matrix scripts as-is (spec-graph sanity)

```pwsh
cd D:\RL\hyper_mve\sdd\pkg-07-baselines       ; pwsh scripts\check_ref_matrix.ps1
cd D:\RL\hyper_mve\sdd\pkg-08-eval-and-ablation; pwsh scripts\check_ref_matrix.ps1
```

Expected: both print `[PASS]`; `ref_matrix.csv` has empty `delta` column. This proves the intra-spec citation graph only — **not** the 4 invariants.

### 0.2 One-shot byte-identity verification of the 4 invariants

Run these four checks interactively at the PowerShell prompt; record output once in a one-page note, then proceed:

```pwsh
# Invariant 4 (cheapest first): 4 planner-mode literals must appear and be exactly 4 distinct strings
$pat = '"(direct_inference|planner_no_crn|planner_no_coord_desc|planner_full)"'
Select-String -Path D:\RL\hyper_mve\sdd\pkg-08-eval-and-ablation\specs\*.md,D:\RL\hyper_mve\sdd\pkg-07-baselines\specs\*.md -Pattern $pat -AllMatches |
  ForEach-Object { $_.Matches.Value } | Sort-Object -Unique
# Expect: exactly 4 lines.

# Invariant 3: 11 REGISTRY keys, deduped, present in both packages
$reg = 'baseline_input_wide|baseline_input_deep|baseline_ma_muzero|no_belief|rewardhead_explicit_type|external_mappo|external_qmix|external_ma_muzero_gh|external_mamba|external_marie|external_ga'
Select-String -Path D:\RL\hyper_mve\sdd\pkg-07-baselines\specs\01-baseline-registry-and-cli.md,D:\RL\hyper_mve\sdd\pkg-08-eval-and-ablation\specs\08-integration-contracts.md -Pattern $reg -AllMatches |
  ForEach-Object { $_.Matches.Value } | Sort-Object -Unique | Measure-Object
# Expect: Count = 11.

# Invariant 2: .evaluate() signature appears in mother + mirrors
Select-String -Path D:\RL\hyper_mve\sdd\pkg-07-baselines\specs\*.md,D:\RL\hyper_mve\sdd\pkg-08-eval-and-ablation\specs\*.md -Pattern 'evaluate\(\s*env_fn\s*,\s*c_grid\s*,\s*episodes\s*\)\s*->\s*EvalReport' | Measure-Object
# Expect: Count >= 5.

# Invariant 1: EvalReport 33 dataclass fields (32 payload + 1 schema_version)
$body = Get-Content D:\RL\hyper_mve\sdd\pkg-08-eval-and-ablation\specs\01-unified-evaluator.md -Raw
$m = [regex]::Match($body, '(?s)@dataclass\(frozen=True\)\s*class EvalReport:.*?schema_version: str = "pkg08-spec01-v1"')
([regex]::Matches($m.Value, '(?m)^\s{4}([a-z_][a-z0-9_]*)\s*:')) | ForEach-Object { $_.Groups[1].Value } | Measure-Object
# Expect: Count = 33.
```

**Exit criterion:** all 4 counts match expectations; both ref-matrix scripts say `[PASS]`. Proceed to Phase 1.

---

## Phase 1 — Schema + adapter (the cross-package interface layer)

| File (create/modify) | Driver spec | What lands |
|---|---|---|
| `hyper_mve/hyper_mve/eval/__init__.py` (new) | pkg-08 spec 01 §1 | package marker |
| `hyper_mve/hyper_mve/eval/eval_report.py` (new) | **pkg-08 spec 01 §3.1** (mother-doc lines 113–185) | `@dataclass(frozen=True) EvalReport` — 32 payload + 1 schema_version sentinel; no logic; byte-faithful to the spec block |
| `hyper_mve/hyper_mve/configs/v4_config.py` (modify) | pkg-07 spec 08 §5.1 + design D10 | append `@dataclass(frozen=True) BaselinesConfig` with the 5 fields, wire as `cfg.baselines: BaselinesConfig` |
| `hyper_mve/hyper_mve/configs/eval_config.py` (modify) | pkg-08 spec 08 §6.3 row B.3 + spec 03 §3 | +2 fields: `eval_planner_mode` (4-literal type), `eval_use_planner_direct_inference: bool = False` |
| `hyper_mve/hyper_mve/configs/train_config.py` (modify) | pkg-08 spec 08 §6.3 row B.2 + spec 06 | +2 fields: `randomize_order: bool = True`, `mve_joint_enumerate: bool = False`; `use_coord_desc` `@property` shim emitting `DeprecationWarning(stacklevel=2)` |
| `hyper_mve/hyper_mve/configs/env_config.py` (modify) | pkg-08 spec 08 §6.3 row B.1 + spec 02 §5.2 | +1 field: `c_visible: bool = True` |
| `hyper_mve/hyper_mve/envs/adapters/__init__.py` (new) | pkg-07 spec 04 §1 | package marker |
| `hyper_mve/hyper_mve/envs/adapters/pettingzoo_wrapper.py` (new) | **pkg-07 spec 04** §3 + §7 | `ResourceCommonsPettingZooEnv(ParallelEnv)`; N-parametric ctor; two-flag `(oracle_mode=False, eval_info_mode=False)` defaults; `_filter_info` strips `c_true / types / hotspot_centers / resource_state` when both flags off |
| `hyper_mve/requirements.txt` (modify) | decision #4 | add `pettingzoo>=1.24`, `gymnasium>=0.29` |

**Reuse:** `hyper_mve/hyper_mve/envs/resource_commons/env.py:ResourceCommonsEnv` (wrap, don't replace); `hyper_mve/hyper_mve/envs/resource_commons/observations.py`; `hyper_mve/hyper_mve/configs/__init__.py` (re-export `BaselinesConfig`).

**Verification:**
```pwsh
pytest D:\RL\hyper_mve\tests\eval\test_eval_report_schema.py D:\RL\hyper_mve\tests\envs\test_pettingzoo_adapter_smoke.py -x
```
Tests must assert: `len(dataclasses.fields(EvalReport)) == 33`; `EvalReport.schema_version == "pkg08-spec01-v1"`; adapter `reset()` returns obs+info dicts with the 4 oracle keys absent under default flags; instantiable at N=2 and N=4.

**Gates covered:** C7-EXT-ADPT1, C7-EXT-ADPT2, and the schema-cardinality assertion that backs every C8-EVAL-* gate.

---

## Phase 2 — Internal baselines (5 model classes) + factory

| File (all new) | Driver spec | What lands |
|---|---|---|
| `hyper_mve/hyper_mve/baselines/__init__.py` | **pkg-07 spec 01 §3** + spec 08 §2 | `create_baseline(cfg, variant)` factory + `INTERNAL_REGISTRY` (5) + `EXTERNAL_REGISTRY` (6) + merged `REGISTRY` (11) as `MappingProxyType`; `BaselineLike` Union alias; `cli_to_factory_arg(cli) -> str`; `create_baseline_model` alias with `DeprecationWarning(stacklevel=2)` |
| `hyper_mve/hyper_mve/baselines/shared_backbones.py` | pkg-07 spec 02 (inherited from pkg-06 spec 02) | `create_rep_net`, `create_belief_net`, `create_tri_context_encoder` — equal-param shared backbone factories (C7-INT-FAIR2) |
| `hyper_mve/hyper_mve/baselines/internal/__init__.py` | pkg-07 spec 03 | package marker |
| `hyper_mve/hyper_mve/baselines/internal/input_conditioned.py` | pkg-07 spec 03 §1 | `InputWideBaselineModel`, `InputDeepBaselineModel` — no DualHyperNetwork (C7-INT-STRUCT1) |
| `hyper_mve/hyper_mve/baselines/internal/ma_muzero.py` | pkg-07 spec 03 §2 | `MAMuZeroBaselineModel` — shared RewardHead (C7-INT-STRUCT2) |
| `hyper_mve/hyper_mve/baselines/internal/no_belief.py` | pkg-07 spec 03 §3 | `NoBeliefBaselineModel` — belief grad gating identical (C7-INT-GRAD1) |
| `hyper_mve/hyper_mve/baselines/internal/explicit_type_reward.py` | pkg-07 spec 03 §4 | `ExplicitTypeRewardBaselineModel` |

Each model class: 7-API per spec 03 §3; `.evaluate(env_fn, c_grid, episodes) -> EvalReport` whose body calls `training/evaluation.py:run_eval` and loops `c_grid` to assemble the 32-field report. Reuses without modification:
- `hyper_mve/hyper_mve/training/muzero_trainer.py:MuZeroTrainer`
- `hyper_mve/hyper_mve/training/worker.py:Worker`
- `hyper_mve/hyper_mve/training/episode_buffer.py:EpisodeReplayBuffer`
- `hyper_mve/hyper_mve/training/loss_composition.py:compose_total_loss`
- `hyper_mve/hyper_mve/models/representation_net.py`, `models/belief_net.py`, `models/tri_context_encoder.py`, `models/functional_nets.py`, `models/grad_gating.py:BeliefGradGating`

**Verification:**
```pwsh
pytest D:\RL\hyper_mve\tests\baselines\test_factory_internal.py D:\RL\hyper_mve\tests\baselines\test_internal_equal_params.py D:\RL\hyper_mve\tests\baselines\test_internal_7api.py -x
```
Covers C7-INT-FACT1, FACT2, FAIR1 (5%/10% threshold), FAIR2, API1, SELF1, REUSE1, GRAD1, STRUCT1, STRUCT2.

---

## Phase 3 — Unified evaluator + planner-mode dispatch + behavioural patches

| File | Driver spec | Change |
|---|---|---|
| `hyper_mve/hyper_mve/eval/unified_evaluator.py` (new) | **pkg-08 spec 01** §2.1 + §4.2 + §5 + §6 + §7.1 | `evaluate(runner, env_fn, cfg) -> EvalReport`; internal branch wraps `training/evaluation.py:run_eval` and loops c-grid via `dataclasses.replace`; external branch delegates to `runner.evaluate(...)` then post-aggregates segment/bell-curve; populates all 32 fields |
| `hyper_mve/hyper_mve/planning/mve_planner.py` (modify) | pkg-08 spec 08 §6.2 patch A | +1 branch: respect `eval_planner_mode` (`direct_inference` → prior shortcut; `planner_no_crn` → CRN off; `planner_no_coord_desc` → coordinate descent off; `planner_full` → current behavior) |
| `hyper_mve/hyper_mve/envs/resource_commons/observations.py` (modify) | pkg-08 spec 08 §6.2 patch A | +3 lines: obs-mask when `cfg.env.c_visible is False` |
| `hyper_mve/hyper_mve/envs/resource_commons/env.py` (modify) | pkg-08 spec 08 §6.2 patch A' | +2 kwarg threading lines (`env_cfg=self.cfg`) into `build_joint_observation()`; `[no-behaviour]` |

**Reuse:** `training/evaluation.py:run_eval` (wrapped per spec 01 Lock 1); `training/worker.py:Worker` (CRN seed already wired).

**Verification:**
```pwsh
pytest D:\RL\hyper_mve\tests\eval\test_unified_evaluator.py D:\RL\hyper_mve\tests\eval\test_4mode_dispatch.py -x
```
Plus a one-line smoke: `evaluate(create_baseline(cfg,'input_wide'), env_fn, cfg)` must return a report with `schema_version=="pkg08-spec01-v1"`, `info_gating_strict is True`, 33 populated fields.

**Gates covered:** C8-EVAL-CHID1, C8-EVAL-MODE1..4, C8-EVAL-EXT1, C8-EVAL-LEAK1, C8-EVAL-REGRET1.

---

## Phase 4 — External runners (3 Tier-1 real ports + 3 stubs) + CLI

**Real ports (all under `hyper_mve/hyper_mve/baselines/external/`):**

| File | Source | Notes |
|---|---|---|
| `__init__.py` | pkg-07 spec 05 §1 | declares `ExternalBaselineRunner` ABC with `.evaluate(env_fn, c_grid, episodes) -> EvalReport` |
| `mappo.py` → `MAPPOAlgorithm` | **`D:\RL\lzj\MAPPO\`** (local 4-file copy) | port `MAPPO_MPE` class algorithm logic intact (lines 111–308 of `mappo.py`); rewrite the `__main__` plumbing to consume `ResourceCommonsPettingZooEnv` via `env_fn`; LR grid `(1e-4, 3e-4, 1e-3)`; module constant `_VENDORED_FROM = "lzj-mappo @ <hash>"` |
| `qmix.py` → `QMIXAlgorithm` | `oxwhirl/pymarl` (Apache 2.0, clone in Phase 4 Day 1) | value decomposition + mixing net; copy `LICENSE` to `_third_party_licenses/pymarl_LICENSE.txt`; `_VENDORED_FROM` constant |
| `ma_muzero_gh.py` → `MAMuZeroGHAlgorithm` | `werner-duvaud/muzero-general` (MIT) | single-agent kernel + hand-written thin MA wrapper per spec 06 §3; license file; `_VENDORED_FROM` constant. **Decision #1: real port this pass.** |

**Stubs (also under `hyper_mve/hyper_mve/baselines/external/`):**

| File | Behavior |
|---|---|
| `mamba.py` → `MAMBAAlgorithm` | module-level `IS_SOURCED = False`; ctor raises `NotImplementedError("MAMBA: Tier-2 stub; pkg-07 design D8 — sourcing window not opened")`. **Decision #2.** |
| `stubs.py` → `MARIEStub`, `GAStub` | both raise `NotImplementedError` on instantiation; CLI/registry slot preserved (C7-EXT-STUB1) |

**CLI modify:**

| File | Change |
|---|---|
| `hyper_mve/hyper_mve/scripts/train_main.py` (modify) | replace `--variant` choices with full 14-list (11 in-registry + `hyper`/`oracle_only`/`infer_only` curriculum-overrides); insert `cli_to_factory_arg` translation; rename CLI flag `use_coord_desc` → `randomize_order` with deprecation shim; **shrink `_DEFERRED_VARIANTS` to only the 3 stub-CLIs** (decision #3) so requesting a stub prints "design D9 stub — see <spec URL>" |

**Verification:**
```pwsh
# Cheap stub gate (must pass before real-port gate):
pytest D:\RL\hyper_mve\tests\baselines\test_external_factory.py D:\RL\hyper_mve\tests\baselines\test_external_stub_raises.py -x

# Real-port smoke (≤20K env-steps on Easy preset; asserts mean return > random baseline):
pytest D:\RL\hyper_mve\tests\baselines\test_external_mappo_smoke.py D:\RL\hyper_mve\tests\baselines\test_external_qmix_smoke.py D:\RL\hyper_mve\tests\baselines\test_external_mamuzero_gh_smoke.py --timeout=900 -x
```

**Gates covered:** C7-EXT-FACT1, C7-EXT-API1, C7-EXT-SMOKE1, C7-EXT-FAIR1, C7-EXT-STUB1.

---

## Phase 5 — Sweep + ablation + stats + compare

| File (all new) | Driver spec | What lands |
|---|---|---|
| `hyper_mve/hyper_mve/experiments/__init__.py` | pkg-08 spec 05 §1 | package marker |
| `hyper_mve/hyper_mve/experiments/run_registry.py` | pkg-08 spec 05 §4 + spec 08 §4 | `@dataclass(frozen=True) RegistryRow` — 22 schema-domain + 1 `schema_version="pkg08-spec05-v1"` = **23 fields**; JSON-serialization helpers |
| `hyper_mve/hyper_mve/experiments/sweep.py` | pkg-08 spec 05 §2, §3, §5 | `sweep` CLI; cartesian over `(variant, preset, seed)`; subprocess-per-row; append-only `runs/registry.jsonl` via `filelock` |
| `hyper_mve/hyper_mve/experiments/ablate.py` | pkg-08 spec 06 (all) | `ablate --ablation <id>` CLI; `ABLATION_IDS = ("abl1","abl4_crn_joint","abl4_joint_easy_n2","abl6","abl7")`; resolves to `SweepConfig` and dispatches into `sweep.py` |
| `hyper_mve/hyper_mve/experiments/ablations/abl1_gen_scope.yaml` | spec 06 §3.1 | 7-cell generalisation-scope grid |
| `hyper_mve/hyper_mve/experiments/ablations/abl4_crn_joint.yaml` | spec 06 §3.2 | 2×2 CRN × CoordDesc on Medium |
| `hyper_mve/hyper_mve/experiments/ablations/abl4_joint_easy_n2.yaml` | spec 06 §3.3 | Easy N=2 exhaustive 36-action enum; **HARD-PINS `preset: easy`** |
| `hyper_mve/hyper_mve/experiments/ablations/abl6_fehr_schmidt.yaml` | spec 06 §3.4 | 3×3 α/β sensitivity |
| `hyper_mve/hyper_mve/experiments/ablations/abl7_curriculum.yaml` | spec 06 §3.5 | 3-cell oracle/mixed/infer |
| `hyper_mve/hyper_mve/experiments/stats.py` | pkg-08 spec 07 §2 | Welch t-test + Holm-Bonferroni; consumes JSONL registry |
| `hyper_mve/hyper_mve/experiments/compare.py` | pkg-08 spec 07 §3 | `compare` CLI — table + matplotlib plot |

**Reuse:** `hyper_mve/hyper_mve/eval/unified_evaluator.py` (Phase 3); `hyper_mve/hyper_mve/baselines/__init__.py:REGISTRY` (Phase 2/4); `hyper_mve/hyper_mve/scripts/train_main.py` (Phase 4) — subprocess per row launches it.

**Verification:**
```pwsh
pytest D:\RL\hyper_mve\tests\experiments\test_run_registry_schema.py D:\RL\hyper_mve\tests\experiments\test_ablation_cli_dispatch.py D:\RL\hyper_mve\tests\experiments\test_stats_holm_bonferroni.py -x

# Tiny end-to-end on Easy N=2 (≤5 min wall-clock):
python -m hyper_mve.experiments.ablate --ablation abl4_joint_easy_n2 --max_steps 200 --seeds 0,1 --runs_root D:\RL\hyper_mve\runs\smoke_phase5
```
Must produce a `registry.jsonl` whose every row has `schema_version=="pkg08-spec05-v1"`; every linked `eval_report.json` deserializes back to a 33-field `EvalReport`.

**Gates covered:** C8-ABL-CLI1, CLI2, CELL1..5; C8-EVAL-SWEEP1..3, STAT1, CMP1.

---

## Phase 6 — End-to-end smoke + final gates

No new files. The integration gate:

```pwsh
# 1. SDD ref-matrix scripts must still PASS (no spec drift):
cd D:\RL\hyper_mve\sdd\pkg-07-baselines       ; pwsh scripts\check_ref_matrix.ps1
cd D:\RL\hyper_mve\sdd\pkg-08-eval-and-ablation; pwsh scripts\check_ref_matrix.ps1
cd D:\RL\hyper_mve

# 2. Full test suites:
pytest D:\RL\hyper_mve\tests -x --timeout=900

# 3. 100-step train smoke per real variant:
$REAL = @("hyper","oracle_only","infer_only",
    "baseline_input_wide","baseline_input_deep","baseline_ma_muzero",
    "no_belief","rewardhead_explicit_type",
    "external_mappo","external_qmix","external_ma_muzero_gh")
foreach ($v in $REAL) {
    python D:\RL\hyper_mve\hyper_mve\scripts\train_main.py --preset easy --variant $v --max_steps 100 --seed 0
    if ($LASTEXITCODE -ne 0) { throw "train_main.py failed for variant=$v" }
}

# 4. Stub registration smoke (must raise NotImplementedError on instantiation):
foreach ($v in @("external_mamba","external_marie","external_ga")) {
    python -c "from hyper_mve.baselines import create_baseline; from hyper_mve.configs import V4Config; create_baseline(V4Config.easy(), '$v')" 2>&1 | Select-String "NotImplementedError"
}

# 5. Unified evaluator + 33-field-populated assertion per real variant:
python -c @'
from hyper_mve.baselines import create_baseline, REGISTRY
from hyper_mve.envs.adapters.pettingzoo_wrapper import ResourceCommonsPettingZooEnv
from hyper_mve.eval.unified_evaluator import evaluate
from hyper_mve.configs import V4Config
from dataclasses import fields
cfg = V4Config.easy()
real = [k for k in list(REGISTRY.keys()) + ["hyper","oracle_only","infer_only"]
        if k not in ("external_mamba","external_marie","external_ga")]
for v in real:
    runner = create_baseline(cfg, v) if v in REGISTRY else __import__("hyper_mve.models", fromlist=["HyperMuZeroModel"]).HyperMuZeroModel(cfg)
    env_fn = lambda: ResourceCommonsPettingZooEnv(cfg.env)
    r = evaluate(runner, env_fn, cfg)
    assert r.schema_version == "pkg08-spec01-v1", v
    assert r.info_gating_strict is True, v
    assert r.set_context_subjective_oracle_leak is False, v
    for f in fields(r):
        if getattr(r, f.name) is None:
            assert f.name in ("belief_c_mae","belief_c_calibration") and v != "hyper", f"unexpected None: {v}.{f.name}"
    print(f"[OK] {v}")
'@
```

If every line of step 5 prints `[OK]`, pkg-07 + pkg-08 are end-to-end wired.

---

## Critical files (the load-bearing 5)

- `hyper_mve/hyper_mve/eval/eval_report.py` (Phase 1)
- `hyper_mve/hyper_mve/envs/adapters/pettingzoo_wrapper.py` (Phase 1)
- `hyper_mve/hyper_mve/baselines/__init__.py` (Phase 2; extended Phase 4)
- `hyper_mve/hyper_mve/eval/unified_evaluator.py` (Phase 3)
- `hyper_mve/hyper_mve/scripts/train_main.py` (modify, Phase 4)

## Acceptance gate coverage map

- **Phase 1** → C7-EXT-ADPT1/2; schema-cardinality assert
- **Phase 2** → C7-INT-FACT1/2, FAIR1/2, API1, SELF1, REUSE1, GRAD1, STRUCT1/2 (10 / 13 INT)
- **Phase 3** → C8-EVAL-CHID1, MODE1..4, EXT1, LEAK1, REGRET1
- **Phase 4** → C7-EXT-FACT1, API1, SMOKE1, FAIR1, STUB1 (5 / 7 EXT)
- **Phase 5** → C8-ABL-CLI1/2, CELL1..5; C8-EVAL-SWEEP1..3, STAT1, CMP1
- **Phase 6** → C7-INT-SMOKE1, C7-EXT-SMOKE1 (carried), C8-EVAL-E2E1, and the meta-assertion that no `EvalReport` field is `None` outside the documented belief-field window
